package com.example.project_car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
