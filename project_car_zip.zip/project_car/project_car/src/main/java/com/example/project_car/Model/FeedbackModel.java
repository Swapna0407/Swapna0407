package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="feedback")
public class FeedbackModel {

    @Id
    private Integer feedbackid;
    private Integer rating;
    private String comment;
    private Integer feedbackdate;

    public FeedbackModel() {
    }

    public FeedbackModel(Integer feedbackid, Integer rating, String comment, Integer feedbackdate) {
        this.feedbackid = feedbackid;
        this.rating = rating;
        this.comment = comment;
        this.feedbackdate = feedbackdate;
    }

    public Integer getFeedbackid() {
        return feedbackid;
    }

    public void setFeedbackid(Integer feedbackid) {
        this.feedbackid = feedbackid;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getFeedbackdate() {
        return feedbackdate;
    }

    public void setFeedbackdate(Integer feedbackdate) {
        this.feedbackdate = feedbackdate;
    }
}
