package com.example.project_car.Repository;

import com.example.project_car.Model.AppointmentModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<AppointmentModel,Integer> {
}
