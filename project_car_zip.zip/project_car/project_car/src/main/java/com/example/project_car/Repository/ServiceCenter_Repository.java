package com.example.project_car.Repository;

import com.example.project_car.Model.ServiceCenter_Model;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceCenter_Repository extends JpaRepository<ServiceCenter_Model,Integer> {
}
