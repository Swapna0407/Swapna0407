package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="appointment")
public class AppointmentModel {


    @Id
    private Integer appointmentid;
    private String appointmentdate;
    private String status;


    public AppointmentModel() {
    }

    public AppointmentModel(Integer appointmentid, String appointmentdate, String status) {
        this.appointmentid = appointmentid;
        this.appointmentdate = appointmentdate;
        this.status = status;
    }


    public Integer getAppointmentid() {
        return appointmentid;
    }

    public void setAppointmentid(Integer appointmentid) {
        this.appointmentid = appointmentid;
    }

    public String getAppointmentdate() {
        return appointmentdate;
    }

    public void setAppointmentdate(String appointmentdate) {
        this.appointmentdate = appointmentdate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
