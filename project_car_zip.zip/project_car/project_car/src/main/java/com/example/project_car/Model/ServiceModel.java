package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="service")
public class ServiceModel {


    @Id
    private Integer serviceid;
    private String servicename;
    private String description;
    private Integer price;


    public ServiceModel() {
    }

    public Integer getServiceid() {
        return serviceid;
    }

    public void setServiceid(Integer serviceid) {
        this.serviceid = serviceid;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public ServiceModel(Integer serviceid, String servicename, String description, Integer price) {
        this.serviceid = serviceid;
        this.servicename = servicename;
        this.description = description;
        this.price = price;
    }



}
