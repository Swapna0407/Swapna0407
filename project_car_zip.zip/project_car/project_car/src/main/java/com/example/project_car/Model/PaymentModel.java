package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="payment")
public class PaymentModel {


    @Id
    private Integer paymentid;
    private String paymentmethod;
    private  Integer amount;
    private Integer paymentdate;

    public PaymentModel() {
    }

    public PaymentModel(Integer paymentid, String paymentmethod, Integer amount, Integer paymentdate) {
        this.paymentid = paymentid;
        this.paymentmethod = paymentmethod;
        this.amount = amount;
        this.paymentdate = paymentdate;
    }

    public Integer getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(Integer paymentid) {
        this.paymentid = paymentid;
    }

    public String getPaymentmethod() {
        return paymentmethod;
    }

    public void setPaymentmethod(String paymentmethod) {
        this.paymentmethod = paymentmethod;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(Integer paymentdate) {
        this.paymentdate = paymentdate;
    }
}
