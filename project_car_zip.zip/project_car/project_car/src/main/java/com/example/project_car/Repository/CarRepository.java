package com.example.project_car.Repository;

import com.example.project_car.Model.CarModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarRepository extends JpaRepository<CarModel,Integer> {
}
