package com.example.project_car.Repository;

import com.example.project_car.Model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository  extends JpaRepository<UserModel,Integer> {

    UserModel findByName(String name);
}
