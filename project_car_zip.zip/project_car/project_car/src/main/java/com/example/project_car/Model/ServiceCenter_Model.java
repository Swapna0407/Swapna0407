package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigInteger;

@Entity
@Table(name="service_center")
public class ServiceCenter_Model {


    @Id
    private Integer serviceCenter_id;
    private String center_name;
    private String center_address;
    private BigInteger center_phonenumber;
    private String email;


    public ServiceCenter_Model() {
    }

    public ServiceCenter_Model(Integer serviceCenter_id, String center_name, String center_address, BigInteger center_phonenumber, String email) {
        this.serviceCenter_id = serviceCenter_id;
        this.center_name = center_name;
        this.center_address = center_address;
        this.center_phonenumber = center_phonenumber;
        this.email = email;
    }

    public Integer getServiceCenter_id() {
        return serviceCenter_id;
    }

    public void setServiceCenter_id(Integer serviceCenter_id) {
        this.serviceCenter_id = serviceCenter_id;
    }

    public String getCenter_name() {
        return center_name;
    }

    public void setCenter_name(String center_name) {
        this.center_name = center_name;
    }

    public String getCenter_address() {
        return center_address;
    }

    public void setCenter_address(String center_address) {
        this.center_address = center_address;
    }

    public BigInteger getCenter_phonenumber() {
        return center_phonenumber;
    }

    public void setCenter_phonenumber(BigInteger center_phonenumber) {
        this.center_phonenumber = center_phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
