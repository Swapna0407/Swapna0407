package com.example.project_car.Controller;


import com.example.project_car.Model.UserModel;
import com.example.project_car.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService service;

    @PostMapping("/addUserModel")
    public UserModel addUserModel(@RequestBody UserModel userModel) {

        return service.saveUserModel(userModel);
    }

    @PostMapping("/addUserModels")
    public List<UserModel> addUserModels(@RequestBody List<UserModel> UserModels) {
        return service.saveUserModels(UserModels);
    }

    @GetMapping("/UserModels")
    public List<UserModel> findAllUserModels() {
        return service.getUserModels();
    }

    @GetMapping("/UserModelByUserId/{userid}")
    public UserModel findUserModelByUserId(@PathVariable int userid) {

        return service.getUserModelById(userid);
    }

    @GetMapping("/userModel/{name}")
    public UserModel findUserModelByName(@PathVariable String name) {

        return service.getUserModelByName(name);
    }

    @DeleteMapping("/delete/{userid}")
    public String deleteUserModel(@PathVariable int userid) {

        return service.deleteUserModel(userid);
    }

    @PutMapping("/update")
    public UserModel updateUserModel(@RequestBody UserModel incominguserModel) { 
        return service.updateUserModel(incominguserModel);


    }

}


