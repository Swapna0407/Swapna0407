package com.example.project_car.Model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Car")
public class CarModel {

    @Id
    private Integer carid;
    private String brand;
    private String Model;

    public CarModel() {

    }

    public CarModel(Integer carid, String brand, String model) {
        this.carid = carid;
        this.brand = brand;
        Model = model;
    }

    public Integer getCarid() {
        return carid;
    }

    public void setCarid(Integer carid) {
        this.carid = carid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }
}

