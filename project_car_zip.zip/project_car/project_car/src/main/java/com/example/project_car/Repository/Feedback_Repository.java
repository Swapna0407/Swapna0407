package com.example.project_car.Repository;

import com.example.project_car.Model.FeedbackModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Feedback_Repository extends JpaRepository<FeedbackModel,Integer> {
}
