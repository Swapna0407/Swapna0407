package com.example.project_car.Service;


import com.example.project_car.Model.UserModel;
import com.example.project_car.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository repository;

    public static boolean updateEmail(Long id, String newEmail) {
        return false;
    }

    public UserModel saveUserModel(UserModel userModel) {
        return repository.save(userModel);
    }

    public List<UserModel> saveUserModels(List<UserModel> UserModels) {
        return repository.saveAll(UserModels);
    }

    public List<UserModel> getUserModels() {
        return repository.findAll();
    }

    public UserModel getUserModelById(int userid) {
        return repository.findById(userid).orElse(null);
    }

    public UserModel getUserModelByName(String name) {
        return repository.findByName(name);
    }

    public String deleteUserModel(int userid) {
        repository.deleteById(userid);
        return "UserModel removed !! " + userid;
    }
    public UserModel updateUserModel(UserModel incominguserModel) {
        return repository.save(incominguserModel);
    }


}