package com.example.project_car.Repository;

import com.example.project_car.Model.ServiceModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceRepository extends JpaRepository<ServiceModel,Integer> {
}
