package com.placement.placementportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementPortalApplication.class, args);
	}

}
