package com.placement.placementportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
